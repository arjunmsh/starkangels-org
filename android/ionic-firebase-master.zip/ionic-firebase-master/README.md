# ionic-firebase
Real Time multi person Chat App using Ionic &amp; Firebase

It uses the AngularFire library to connect to firebase.
